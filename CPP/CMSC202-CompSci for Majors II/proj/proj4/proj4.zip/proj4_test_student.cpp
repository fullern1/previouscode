#include <iostream>
#include <vector>
#include "WalkGraph.h"
#include "WalkEdge.h"
#include "WalkVertex.h"
#include "Intersection.h"
#include "SafeHouse.h"
#include "PoliceStation.h"
#include "/afs/umbc.edu/users/c/m/cmarron/pub/gtest-1.7.0/include/gtest/gtest.h"
//#include "../gtest-1.7.0/include/gtest/gtest.h"

using namespace std;

TEST(Project4_STUDENT, WalkGraph_Walk) {

  /* Test code goes here */
  
}

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
